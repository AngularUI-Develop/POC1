export class User{
    email: string;
    passwod:string;    
}